package com.example.libres;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class telaGeneros extends AppCompatActivity {
    private final String[] generos =
            {
                    "Ação e Aventura", "Autoajuda",
                    "Biografia e Autobiografia", "Distopia",
                    "Arte e Fotografia", "Fantasia",
                    "Ficção Científica", "Horror",
                    "Ficção Policial", "Romance",
                    "Mistério e Investigação", "Suspense",
                    "Ficção Histórica", "Graphic Novel",
                    "Ficção Contemporânea", "Young Adult",
                    "Histórias em Quadrinhos", "Infantil",
                    "Religião e Espiritualidade", "Gastronomia",
                    "Guias e Tutoriais", "Viagens",
                    "Tecnologia e Ciência", "Humor",
                    "Familiar"
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_generos);

        GridLayout gridLayout = findViewById(R.id.genresGrid);
        Button doneButton = findViewById(R.id.btnPronto);

        // Adiciona os CheckBoxes ao GridLayout
        for (String genre : generos) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(genre);

            // Configuração do LayoutParams para o GridLayout
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0; // 0 significa que usará weight
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); // 1f é o weight
            params.setMargins(0, 8, 0, 8);

            checkBox.setLayoutParams(params);
            gridLayout.addView(checkBox);

            // Configura o listener do botão
            doneButton.setOnClickListener(new View.OnClickListener()
            {

                @Override
                public void onClick(View v)
                {
                    // Lógica de coleta aqui

                List<String> selectedGenres = new ArrayList<>();

                // Percorre todos os views no GridLayout
                for (int i = 0; i < gridLayout.getChildCount(); i++)
                {
                    View view = gridLayout.getChildAt(i);
                    if (view instanceof CheckBox)
                    {
                        CheckBox checkBox = (CheckBox) view;
                        if (checkBox.isChecked())
                        {
                            selectedGenres.add(checkBox.getText().toString());
                        }
                    }
                }

                // Exibe uma mensagem com a quantidade de gêneros selecionados
                Toast.makeText(telaGeneros.this,
                        "Gêneros selecionados: " + selectedGenres.size(),
                        Toast.LENGTH_SHORT).show();

                // Aqui você pode adicionar a lógica para prosseguir com os gêneros selecionados
            }
            });
        }
    }
}


